const HI = "hi"
const EN = "en"
module.exports ={HI,EN}